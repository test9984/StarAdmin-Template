// import { Component, OnInit } from '@angular/core';
// import { ViewEncapsulation } from '@angular/core';
// import { User, Userservice } from '../service/userdataservice';

// @Component({
//   selector: 'app-buttons',
//   templateUrl: './buttons.component.html',
//   styleUrls: ['./buttons.component.scss'],
//   encapsulation: ViewEncapsulation.None
// })
// export class ButtonsComponent implements OnInit {
//   model = 1;
//   checkboxModel = {
//    left: true,
//    middle: false,
//    right: false
//  };
//  listUser: User[]
//   constructor(private userService:Userservice) { }

//   ngOnInit() {
//     this.getAllUser();
//   }


//   getAllUser(){
//     return this.userService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listUser= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }




import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { UserDataService } from '../service/userdataservice';
import { Role } from '../carousel/carousel.component';
import { WorkspaceDataService } from '../service/workspacedataservice';

import { Workspace } from 'src/app/dropdown/dropdown.component';




export class User {

  public id: number
  public firstName: string
  public lastName: string
  public emailAddress: string
  public password: string
  public organizationName: string
  public country: string
  public questionAnswer: string
  public photo: Blob
  public accountExpired: boolean
  public accountLocked: boolean
  public credentialExpired: boolean
  public accountEnabled: boolean
  public createdBy: string
  public createdDate: Date
  public updatedBy: string
  public updatedDate: Date
  public firstLogin: boolean
  public isEditable: boolean
  public rolesList: Role[]
  public workspacesList: Workspace[]
  constructor(

  ) {

  }

}
 @Component({
 selector: 'app-buttons',
  templateUrl: './buttons.component.html',
   styleUrls: ['./buttons.component.scss'],
//   encapsulation: ViewEncapsulation.None
 })
export class ButtonsComponent implements OnInit  {
  users: User[]
  deleteMsg: string
  updateMsg: string
  constructor(private usersService: UserDataService, private router: Router) { }

  ngOnInit() {
    this.getAllUsers()
  }
  getAllUsers() {
    this.usersService.getAllUsers().subscribe(
      response => this.handleSuccessResp(response),
      error => this.handleErrorResp(error)
    )
  }
  handleErrorResp(error) {
    console.log(error)
  }
  handleSuccessResp(response) {
    this.users = response.data;
  }

  // editUser(userid) {

  //   this.router.navigate(['forms'])


  // }

  // editUser(user: User): void {
  //   window.localStorage.removeItem("editUserId");
  //   window.localStorage.setItem("editUserId", user.id.toString());
  //   this.router.navigate(['alerts']);
  // };
  updateUser(userid) {
    console.log(userid)
    this.usersService.updateUser(userid).subscribe(
      response => {
      
      this.updateMsg = "SuccessFull update"
        this.getAllUsers()
      },
      error => this.updateMsg = "Error to update role"

    )
    this.router.navigate(['pagination']);
  }
  deleteUser(userid) {
    console.log(userid)
    this.usersService.deleteUserById(userid).subscribe(
      response => {
      this.deleteMsg = "SuccessFull delete"
        this.getAllUsers()
      },
      error => this.deleteMsg = "Error to delete role"

    )
  }
  // addUser() {
  //   this.router.navigate(['/users', 0])
  // }
}









