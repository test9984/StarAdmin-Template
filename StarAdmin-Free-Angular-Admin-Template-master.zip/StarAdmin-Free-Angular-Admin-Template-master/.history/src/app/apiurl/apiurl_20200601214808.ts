export class APIURL {
    public static USER_DATA_API_ENDPOINT='http://localhost:9093/user-management/users';
    public static ROLE_DATA_API_ENDPOINT='http://localhost:9093/user-management/role';
    public static PERMISSION_DATA_API_ENDPOINT='http://localhost:9093/user-management/permission';
  
    public static USER_DATA_ADD_API_ENDPOINT='http://localhost:9093/user-management/users';
    public static WORKSPACE_DATA_API_ENDPOINT='http://localhost:9093/user-management/workspaces';
}