// export class APIURL {
//     public static USER_DATA_API_ENDPOINT='http://localhost:9093/user-management/users';
//     public static ROLE_DATA_API_ENDPOINT='http://localhost:9093/user-management/roles';
//     public static PERMISSION_DATA_API_ENDPOINT='http://localhost:9093/user-management/permissions';
  
//    // public static USER_DATA_ADD_API_ENDPOINT='http://localhost:9093/user-management/users';
//     public static WORKSPACE_DATA_API_ENDPOINT='http://localhost:9093/user-management/workspaces';
// }


export class APIURL {
    public static WELCOME_DATA_API_ENDPOINT='http://localhost:9093/user-management/welcome';
    public static PERMISSION_DATA_API_ENDPOINT='http://localhost:9093/user-management/permissions';
    public static ROLE_DATA_API_ENDPOINT='http://localhost:9093/user-management/roles';
    public static USER_DATA_API_ENDPOINT='http://localhost:9093/user-management/users';
    public static WORKSPACE_DATA_API_ENDPOINT='http://localhost:9093/user-management/workspaces';
   public static UPDATE_USER_DATA_API_ENDPOINT='http://localhost:9093/user-management/users/';
   public static UPDATE_ROLE_DATA_APIENDPOINT='http://localhost:9093/user-management/users';

}