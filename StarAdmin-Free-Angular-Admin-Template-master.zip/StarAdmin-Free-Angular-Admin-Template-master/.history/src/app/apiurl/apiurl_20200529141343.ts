export class APIURL {
    public static USER_API_ENDPOINT='http://localhost:9093/user-management/users';
    public static ROLE_API_ENDPOINT='http://localhost:9093/user-management/roles';
    public static PERMISSION_API_ENDPOINT='http://localhost:9093/user-management/permissions';
  
    public static USER_ADD_API_ENDPOINT='http://localhost:9093/user-management/users';
    public static WORKSPACE_API_ENDPOINT='http://localhost:9093/user-management/workspaces';
}