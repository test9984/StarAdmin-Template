import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Role, Roleservice } from '../service/roleservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  encapsulation: ViewEncapsulation.None


})
export class CarouselComponent implements OnInit {

 
  


  listRole: Role[]
 




  
    registerForm: FormGroup;
    submitted = false;
 
    constructor(private formBuilder: FormBuilder) { }
 
    ngOnInit() {
    //  this.getAllRole();
        this.registerForm = this.formBuilder.group({
            roleName: ['', Validators.required],
            roleDescription: ['', Validators.required],
           
            
        });
    }
    onSubmit() {
      this.submitted = true;

      // stop the process here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!!');
  }
}
//   getAllRole(){
//     return this.roleService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listRole= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }
