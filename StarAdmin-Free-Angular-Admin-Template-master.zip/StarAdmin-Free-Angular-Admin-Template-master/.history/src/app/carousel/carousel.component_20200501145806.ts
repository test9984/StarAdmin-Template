import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Role, Roleservice } from '../service/roleservice';
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  encapsulation: ViewEncapsulation.None


})
export class CarouselComponent implements OnInit {

 
  


  listRole: Role[]
  constructor(private roleService:Roleservice) { }

  ngOnInit() {
    this.getAllRole();
  }


  getAllRole(){
    return this.roleService.getAllWelcomeMsg().subscribe(
      response=>{console.log(response)
      this.listRole= this.getData(response);
      },
    error=>console.log(error))
    
    
  }
  getData (response){
    return response.data;
  }
}
