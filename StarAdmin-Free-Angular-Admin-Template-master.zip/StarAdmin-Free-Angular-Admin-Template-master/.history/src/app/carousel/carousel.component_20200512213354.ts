import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Role, Roleservice } from '../service/roleservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CarouselComponent implements OnInit {

 listRole: Role[]
 registerForm: FormGroup;
  submitted = false;
  role:Role[];
  message: String;




    constructor(private formBuilder: FormBuilder, private roleService:Roleservice) { }
 
    ngOnInit() {
    //  this.getAllRole();
        this.registerForm = this.formBuilder.group({
            roleName: ['', Validators.required],
            roleDescription: ['', Validators.required],
           
            
        });
    }
    get f(){return this.registerForm.controls;}
    onSubmit() {
      this.submitted = true;

      // stop the process here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
      this.users=this.registerForm.value;
      this.roleService.addUser(this.users).subscribe((res)=>{
        this.message=this.getSuccessMessage(res)
      });
        //this.registerForm.reset();
    
      }

          getSuccessMessage(res){

    return res.isSuccess
  }
      getAllUsers(){
return this.roleService.getAllWelcomeMsg().subscribe(

  response=>{console.log(response)
    this.listRole=this.getData(response);
  },
  error=>console.log(error)  )
}
getData(response){
return response.data;
}
  }
//   getAllRole(){
//     return this.roleService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listRole= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }
