// import { Component, OnInit } from '@angular/core';
// import { ViewEncapsulation } from '@angular/core';
// import { Role, Roleservice } from '../service/roleservice';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';

// @Component({
//   selector: 'app-carousel',
//   templateUrl: './carousel.component.html',
//   styleUrls: ['./carousel.component.scss'],
//   encapsulation: ViewEncapsulation.None
// })
// export class CarouselComponent implements OnInit {

//  listRole: Role[]
//  registerForm: FormGroup;
//   submitted = false;
//   roles:Role[];
//   message: String;




//     constructor(private formBuilder: FormBuilder, private roleService:Roleservice) { }
 
//     ngOnInit() {
//      this.getAllRole();
//         this.registerForm = this.formBuilder.group({
//             roleName: ['', Validators.required],
//             roleDescription: ['', Validators.required],
           
            
//         });
//     }
//     get f(){return this.registerForm.controls;}
//     onSubmit() {
//       this.submitted = true;

//       // stop the process here if form is invalid
//       if (this.registerForm.invalid) {
//           return;
//       }

//       alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
//       this.roles=this.registerForm.value;
//       this.roleService.addUser(this.roles).subscribe((res)=>{
//         this.message=this.getSuccessMessage(res)
//       });
//        // this.registerForm.refresh();
    
//       }

//           getSuccessMessage(res){

//     return res.isSuccess
//   }
//       getAllRole(){
// return this.roleService.getAllWelcomeMsg().subscribe(

//   response=>{console.log(response)
//     this.listRole=this.getData(response);
//   },
//   error=>console.log(error)  )
// }
// getData(response){
// return response.data;
// }
//   }
//   getAllRole(){
//     return this.roleService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listRole= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }





// import { Component, OnInit } from '@angular/core';
// import { ViewEncapsulation } from '@angular/core';
// import { Role, Roleservice } from '../service/roledataservice';

// @Component({
//   selector: 'app-carousel',
//   templateUrl: './carousel.component.html',
//   styleUrls: ['./carousel.component.scss'],
//   encapsulation: ViewEncapsulation.None
// })
// export class CarouselComponent implements OnInit {
//   model = 1;
//   checkboxModel = {
//    left: true,
//    middle: false,
//    right: false
//  };

//  listRole: Role[]
//   constructor(private roleService:Roleservice) { }

//   ngOnInit() {
//     this.getAllRole();
//   }


//   getAllRole(){
//     return this.roleService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listRole= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }







import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Permission } from 'src/app/tabs/tabs.component';
import { RoleDataService } from '../service/roledataservice';
export class Role{

 

 
 
  constructor(  
    public id: number,
    public roleName: string,
    public roleDescription: string,
    public permissionsList:Permission[]= []) {

}
}

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],

})
export class CarouselComponent implements OnInit{
roles:Role[]
deleteMsg: string;
  constructor(private roleDataService:RoleDataService,private router:Router) { }

  ngOnInit() {
    this.getAllRoles()
  }

  getAllRoles(){
    this.roleDataService.getAllRoles().subscribe(
      response=>this.handleSuccessResp(response),
      error=>this.handleErrorResp(error)
    )
  }
  updateRole(roleId){
      this.router.navigate(['tooltips'])
  
  }
  // updateData(){
  //   this.service.updateUserData({group.Name:this.list}).subscribe(res=>{
  //     console.log('update data',res);
  //     this.list1=res;
  //   },error=>{
  //     console.log("error2",error);
  //   })
  //   }
  deleteRole(roleId){
    
    this.roleDataService.deleteRoleById(roleId).subscribe(
      response=>{this.deleteMsg="SuccessFull delete"
      this.getAllRoles()
    },
      error=>this.deleteMsg="Error to delete role"

    )
  }
  handleSuccessResp(response){
    this.roles=response.data
  }

  handleErrorResp(error){
    console.log(error)
  }

}

