import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Role, Roleservice } from '../service/roleservice';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import{Observable ,interval,Subscription} from 'rxjs';
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CarouselComponent implements OnInit {
 private updateSubscription :Subscription;
 listRole: Role[]
 registerForm: FormGroup;
  submitted = false;
  roles:Role[];
  message: String;




    constructor(private formBuilder: FormBuilder, private roleService:Roleservice) { }
 
    ngOnInit() {
      this.updateSubscription = interval(1000).subscribe(
(val)=>{this.updateStats()
}
      );
     this.getAllRole();
        this.registerForm = this.formBuilder.group({
            roleName: ['', Validators.required],
            roleDescription: ['', Validators.required],
           
            
        });
    }
    get f(){return this.registerForm.controls;}
    onSubmit() {
      this.submitted = true;

      // stop the process here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
      this.roles=this.registerForm.value;
      this.roleService.addUser(this.roles).subscribe((res)=>{
        this.message=this.getSuccessMessage(res)
      });
        //this.registerForm.reset();
    
      }

          getSuccessMessage(res){

    return res.isSuccess
  }
      getAllRole(){
return this.roleService.getAllWelcomeMsg().subscribe(

  response=>{console.log(response)
    this.listRole=this.getData(response);
  },
  error=>console.log(error)  )
}
getData(response){
return response.data;
}
  }
//   getAllRole(){
//     return this.roleService.getAllWelcomeMsg().subscribe(
//       response=>{console.log(response)
//       this.listRole= this.getData(response);
//       },
//     error=>console.log(error))
    
    
//   }
//   getData (response){
//     return response.data;
//   }
// }
