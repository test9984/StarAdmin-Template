// import { Component, OnInit, ViewChild } from '@angular/core';
// import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
// import { Subject } from 'rxjs/Subject';
// import { Observable } from 'rxjs/observable';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/debounceTime';
// import 'rxjs/add/operator/distinctUntilChanged';
// import 'rxjs/add/operator/merge';
// import 'rxjs/add/operator/filter';

// const states = ['Alabama', 'Alaska', 'American Samoa', 'Arizona', 'Arkansas', 'California', 'Colorado',
//   'Connecticut', 'Delaware', 'District Of Columbia', 'Federated States Of Micronesia', 'Florida', 'Georgia',
//   'Guam', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine',
//   'Marshall Islands', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana',
//   'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
//   'Northern Mariana Islands', 'Ohio', 'Oklahoma', 'Oregon', 'Palau', 'Pennsylvania', 'Puerto Rico', 'Rhode Island',
//   'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virgin Islands', 'Virginia',
//   'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];

// @Component({
//   selector: 'app-forms',
//   templateUrl: './forms.component.html',
//   styleUrls: ['./forms.component.scss']
// })
// export class FormsComponent implements OnInit {
//   currentRate: any;
//   public typeaheadBasicModel: any;
//   public typeaheadFocusModel: any;

//   constructor() { }

//   search = (text$: Observable<string>) =>
//     text$
//       .debounceTime(200)
//       .distinctUntilChanged()
//       .map(term => term.length > 1 ? []
//         : states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10));

//   @ViewChild('instance', {static: true}) instance: NgbTypeahead;
//   focus$ = new Subject<string>();
//   click$ = new Subject<string>();

//   focusSearch = (text$: Observable<string>) =>
//     text$
//       .debounceTime(200).distinctUntilChanged()
//       .merge(this.focus$)
//       .merge(this.click$.filter(() => !this.instance.isPopupOpen()))
//       .map(term => (term === '' ? states : states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10));


//   ngOnInit() {
//     this.currentRate = 8;
//   }

// }



import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ViewEncapsulation } from '@angular/core';
import { User, Userservice } from '../service/userservice';
import { Role, Roleservice } from '../service/roleservice';
import { Workspace, Workspaceservice } from '../service/workspaceservice';
// import custom validator to validate that password and confirm password fields match
//import { MustMatch } from './_helpers/must-match.validator';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormsComponent implements OnInit {
  [x: string]: any;
  registerForm: FormGroup;
    submitted = false;
  users: User;
  message: String;
  //listUser: User[];
  listRole: Role[];
  listWorkspace: Workspace[];
    constructor(private formBuilder: FormBuilder, private userService:Userservice,private roleService:Roleservice,private workspaceService:Workspaceservice, private route: ActivatedRoute,) { }

    ngOnInit() {
      this.getAllWorkspace();
      this.users = new User();
      this.registerForm = this.getControls();
        // this.registerForm = this.formBuilder.group({
           
        //     firstName: ['', Validators.required],
        //     lastName: ['', Validators.required],
        //     emailAddress: ['', [Validators.required, Validators.email]],
        //     password: ['', [Validators.required,  Validators.pattern('((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,30})')]],
        //     role: ['', Validators.required],
        //     workspacesList: ['', Validators.required]
           
        // }, {
            
        // });
      }



      getAllRole(){
        return this.roleService.getAllWelcomeMsg().subscribe(
      
          response=>{console.log(response)
            this.listRole=this.getData(response);
          },
          error=>console.log(error)  )
      }
    
      getAllWorkspace() {
        return this.workspaceService.getWorkspace().subscribe(
          response => {
            console.log(response)
            this.listWorkspace = this.getData(response);
          },
          errror => console.log(errror))
    
      }

  onWorkspaceSelected(e) {
    this.users.workspacesList = []
    // console.log("the selected woekspace id value is " + value);
    console.log(e.target.value)
    this.users.workspacesList.push(new Workspace(e.target.value, '', ''))
  }


  // onRoleSelected(e) {
  //   console.log(e.target.value);
  //   // this.users.country=e.target.value;
  //   // console.log(this.users.country);
  //   this.forms.rolesList = []
  //   //console.log("the selected Role id value is " + value);
  //   this.users.rolesList.push(new Role(e.target.value, '', ''))
  // }


  getControls() {
    return this.formBuilder.group({

     firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            emailAddress: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required,  Validators.pattern('((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,30})')]],
            role: ['', Validators.required],
            workspacesList: ['', Validators.required]

    });
  }





      get f(){return this.registerForm.controls;}
      onSubmit() {
        this.submitted = true;
 
        // stop the process here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
 






        
        alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value, null, 4));
       this.users=this.registerForm.value;
        this.userService.addUser(this.users).subscribe((res)=>{
          this.message=this.getSuccessMessage(res)
        });
          //this.registerForm.reset();
          this.router.navigate(['/pages/users/inputs']);

        }

            getSuccessMessage(res){

      return res.isSuccess
    }
        getAllUsers(){
  return this.userService.getAllWelcomeMsg().subscribe(

    response=>{console.log(response)
      this.listUser=this.getData(response);
    },
    error=>console.log(error)  )
}
getData(response){
  return response.data;
}
    }
    

    



//     onSubmit() {
//         this.submitted = true;

// //         // stop here if form is invalid
//          if (this.userForm.invalid) {
//              return;
//          }

// //         // display form values on success
//         alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.userForm.value, null, 4));

//     }

//     onReset() {
//       this.submitted = false;
//       this.userForm.reset();
//   }


//}
// }
//         this.formBuilder=this.userForm.value;
//         this.formBuilder.addUser(this.users).subscribe((res)=>{
//           this.message=this.getSuccessMessage(res)
//         });
//           this.userForm.reset();
//          // console.logthis.users()

//         }
//     getSuccessMessage(res){

//       return res.isSuccess
//     }
//     getAllUsers(){
//   return history.formBuilder.getUsers().subscribe(

//     response=>{console.log(response)
//       this.getAllUsers=this.getData(response);
//     },
//   )
// }
  
 //}


