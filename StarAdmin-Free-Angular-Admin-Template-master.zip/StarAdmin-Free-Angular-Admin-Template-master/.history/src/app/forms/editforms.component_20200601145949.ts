import { Component, OnInit } from '@angular/core';  
import { FormGroup, FormBuilder, Validators } from '@angular/forms';  
import { ActivatedRoute, Router } from '@angular/router';  
//import { ProductsService } from '../products.service'; 
import { User, Userservice } from '../service/userservice';
import { ViewEncapsulation } from '@angular/core'; 
@Component({
    selector: 'app-forms',
    templateUrl: './editforms.component.html',
    styleUrls: ['./editforms.component.scss'],
    encapsulation: ViewEncapsulation.None
  }) 
export class editformsComponent implements OnInit {  
    registerForm: FormGroup;  
 product: any = {};  
  constructor(private route: ActivatedRoute, private router: Router,private userService:Userservice, private formBuilder: FormBuilder) {  
      this.createForm();  
 }  
  createForm() {  
    this.registerForm = this.formBuilder.group({
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        emailAddress: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required,  Validators.pattern('((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,30})')]],
        role: ['', Validators.required],
        workspace: ['', Validators.required]
       
    });  
  }  







  ngOnInit() {  
    this.route.params.subscribe(params => {  
        this.userService.editProduct(params['id']).subscribe(res => {  
          this.product = res;  
      });  
    });  
  }  
}  