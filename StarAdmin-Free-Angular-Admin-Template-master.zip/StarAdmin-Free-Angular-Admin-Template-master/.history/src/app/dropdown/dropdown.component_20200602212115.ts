// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-dropdown',
//   templateUrl: './dropdown.component.html',
//   styleUrls: ['./dropdown.component.scss']
// })
// export class DropdownComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }



import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { WorkspaceDataService } from '../service/workspacedataservice';

export class Workspace {

  constructor(
    public id: number,
    public workspaceName: string,
    public workspaceDesc: string
  ) {

  }
}

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {
  workspaces: Workspace[]
  deleteMsg: string
  constructor(private workspaceDataService: WorkspaceDataService, private router: Router) { }

  ngOnInit() {
    this.getAllWorkspaces()
  }

  getAllWorkspaces() {
    this.workspaceDataService.getAllWorkspaces().subscribe(
      data => this.handleSuccessResponse(data),
      error => console.log(error)
    )
  }


  editworkspace(workspaceId){
  


    this.router.navigate(['/progressbar'])


  }
  deleteworkspace(workspaceId) {
    this.workspaceDataService.deleteWorkspacebyId(workspaceId).subscribe(
      data => {
        this.deleteMsg = `workspace id  ${workspaceId} is deleted`
        this.getAllWorkspaces()
      },
      error => this.deleteMsg = `fail to delete workspace id  ${workspaceId}`
    )
  }


  addworkspce() {
    this.router.navigate(["workspaces", 0])
  }
  handleSuccessResponse(data) {
    this.workspaces = data.data
    console.log(this.workspaces)
  }

}
