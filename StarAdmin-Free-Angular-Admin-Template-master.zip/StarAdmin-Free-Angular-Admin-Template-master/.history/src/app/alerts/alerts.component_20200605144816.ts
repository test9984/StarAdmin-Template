// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-alerts',
//   templateUrl: './alerts.component.html',
//   styleUrls: ['./alerts.component.scss']
// })
// export class AlertsComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }










import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/buttons/buttons.component';

import { Role } from 'src/app/carousel/carousel.component';
 import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Workspace } from 'src/app/dropdown/dropdown.component';
import { ActivatedRoute, Router } from '@angular/router';
import { UserDataService } from '../service/userdataservice';
import { RoleDataService } from '../service/roledataservice';
import { WorkspaceDataService } from '../service/workspacedataservice';
// import custom validator to validate that password and confirm password fields match
//import { MustMatch } from './_helpers/must-match.validator';
import {first} from "rxjs/operators";
@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent implements OnInit {
  registerForm: FormGroup;
  user: User
  roles: Role[]
  workspaces: Workspace[]
  roleId: number
  workspaceId: number
  id: number
  isReadOnly = false
  editForm: FormGroup
  constructor(
    private formBuilder: FormBuilder,
    private userDataService: UserDataService,
    private roleDataService: RoleDataService,
    private workspaceDataService: WorkspaceDataService,
    private router: ActivatedRoute,
    private route: Router
  ) { }


  ngOnInit() {
    this.id = this.router.snapshot.params['userId']
    this.user = new User()
    this.getAllRoles()
    this.getAllWorkspaces()

    if (this.id != 0 && this.id != null) {
      this.userDataService.getUserById(this.id).subscribe(
        response => {
          this.handleSuccessUser(response)
          this.isReadOnly = true
        },
        error => console.log(error)

      )
    }
  }
  handleSuccessUser(response) {
    this.user = response.data
    if (this.user.workspacesList) {
      this.workspaceId = this.user.workspacesList[0].id
    }
    if (this.user.rolesList) {
      this.roleId = this.user.rolesList[0].id
    }
  }

  getAllWorkspaces() {
    this.workspaceDataService.getAllWorkspaces().subscribe(
      data => {
        this.handleSuccessWorkSpace(data)
        this.workspaceId = this.workspaces[0].id
      },
      error => console.log(error)

    )
  }
  handleSuccessWorkSpace(response) {
    this.workspaces = response.data;
  }

  onWorkspaceSelected(value: any) {
    this.user.workspacesList = []
    console.log("the selected woekspace id value is " + value);
    this.user.workspacesList.push(new Workspace(value, '', ''))
  }
  getAllRoles() {
    this.roleDataService.getAllRoles().subscribe(
      data => {
        this.handleSuccessRole(data)
        this.roleId = this.roles[0].id
      },
      error => console.log(error)

    )
  }


  handleSuccessRole(response) {
    this.roles = response.data;
  }

  onRoleSelected(value: any) {
    this.user.rolesList = []
    console.log("the selected Role id value is " + value);
    this.user.rolesList.push(new Role(value, '', ''))
  }




  
  onSubmit() {
    this.userDataService.updateUser(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert('User updated successfully.');
            this.route.navigate(['list-user']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }
  handleSuccessResp(response) {
    console.log(response)
  }

  handleErrorResp(error) {
    console.log(error)
  }

}





